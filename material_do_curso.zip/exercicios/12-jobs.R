# 1. A partir do exemplo mostrado em aula, encontre uma forma de separar os
# links para as vagas ("apply") dos links para a home do site ("learn") sem usar
# o {stringr}. Só vale usar o XPath!

# 2. A partir do exemplo mostrado em aula, transforme todo o conteúdo da função
# parse_job() em uma única pipeline (exceto pelo objeto `xpaths`).

# 3. A partir do exemplo mostrado em aula, com a própria função map_dfr(),
# encontre uma maneira simples de criar uma coluna com o link para vaga no
# data frame final.
