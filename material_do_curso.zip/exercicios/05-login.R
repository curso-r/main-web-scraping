# 1. Faça o login na página do exemplo (https://quotes.toscrape.com)

# 2. Monte uma base de dados com os quotes da primeira página, contendo,
# pelo menos, texto e autor(a).