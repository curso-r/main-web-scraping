# 1. Faça um script que seja capaz de baixar a base de dados utilizada pelo
# pesqEle. Ela pode ser acessada pelo botão "Download" na direita superior do
# app.

# 2. [Dissertativa] Verifique quais informações podem ser extraídas **sem**
# webdriver. Use o resto do conhecimento obtido ao longo do curso para explorar
# o aplicativo.
