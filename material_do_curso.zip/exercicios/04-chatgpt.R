# 1. Coloque sua chave de acesso ao ChatGPT em uma variável de ambiente

# 2. Gere uma mensagem com ChatGPT

# 3. Usando o ChatGPT, gere um código para criar um web scraper da seguinte página: 
# https://pt.wikipedia.org/wiki/Lista_de_unidades_federativas_do_Brasil_por_popula%C3%A7%C3%A3o
