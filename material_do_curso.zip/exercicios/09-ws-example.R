# 1. Adicione tratamento de erros e barras de progresso na função
# de baixar uma página

# http://example.webscraping.com

# 2. Rode a função de baixar páginas em paralelo

# 3. Verifique se todos os arquivos baixaram corretamente
# Obs: Pode ser que seu IP tenha sido bloqueado!

# 4. Como você resolveria esse problema?