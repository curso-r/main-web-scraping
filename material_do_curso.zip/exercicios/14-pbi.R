# 1. Aproveitando o código apresentado em aula, faça uma breve análise
# comparando os dados do DataJud na Justiça Estadual da Bahia e de Minas Gerais

# 2. [Dissertativa] Descreva como você poderia utilizar a função scrollBy() para
# descobrir automaticamente a localização do elemento de interesse, ou seja,
# sem precisar encontrar de antemão o número de pixels a serem rolados.
