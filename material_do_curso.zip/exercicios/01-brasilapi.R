
u_base <- "https://brasilapi.com.br/api"

# 1. Acesse todos os bancos na API
# Dica: qual é o endpoint que devemos utilizar?

# 2. Pesquise o preço de um carro de interesse
# Dica: veja nos exemplos de aula uma forma de achar um código de carro
# Dica: qual endpoint devemos utilizar?

# 3. Pesquise o preço de um carro de interesse, mas na tabela de dez/2019
# você identificou alguma diferença?

# 4. Construa uma base de dados de todos os feriados nacionais entre 2000 e 2030
