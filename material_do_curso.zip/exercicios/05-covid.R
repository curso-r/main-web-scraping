library(tidyverse)
library(httr)

u_msaude <- "https://covid.saude.gov.br"

# 1. baixe e carregue a base do covid no objeto tab_covid



# 2. Rode tibble::glimpse(tab_covid, 50)



# 3. [extra] monte um gráfico mostrando taxa acumulada de mortes pela população, 
# ao longo das semanas epidemiológicas, para cada estado. 


