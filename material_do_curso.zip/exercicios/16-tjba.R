# 1. [Dissertativa] Paralelizar a modelos de deep learning diretamente é muito
# difícil pois o TensorFlow já utiliza todos os recursos disponíveis do
# computador. Tendo isso em vista, como você faria para implementar uma versão
# paralelizada do resto do código apresentado em aula?
