# 1. Com base no que foi aprendido em aula, monte uma base de dados com as
# primeiras 3 páginas da consulta da Anatel, a partir to termo de busca "vivo"
