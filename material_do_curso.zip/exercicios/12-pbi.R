# 1. Aproveitando o código apresentado em aula, faça uma breve análise
# comparando os dados de Covid do Brasil com os do mundo todo. Crie um código
# que extraia os dados do PBI sem intervenção humana.

# 2. [Dissertativa] Como você poderia utilizar a função scrollBy() para
# descobrir automaticamente a localização do elemento de interesse, ou seja,
# sem precisar encontrar de antemão o número de pixels a serem rolados.
