# Faça um script para baixar a base de dados usando webdriver

# Verifique quais informações são possíveis de extrair sem webdriver
