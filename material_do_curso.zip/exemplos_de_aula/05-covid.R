library(tidyverse)
library(httr)

u_msaude <- "https://covid.saude.gov.br"

# (live)
