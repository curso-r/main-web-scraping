library(tidyverse)

u <- "http://example.webscraping.com"

# baixar uma pagina

# scrapear uma pagina

# baixar um pais

# scrapear um pais